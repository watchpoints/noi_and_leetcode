void prog_initialize();
int ask_x(int,double*,double*);
int ask_y(int,double*,double*);
void ret_n(int);
void ret_area(double);
void ret_vertex(int,int);